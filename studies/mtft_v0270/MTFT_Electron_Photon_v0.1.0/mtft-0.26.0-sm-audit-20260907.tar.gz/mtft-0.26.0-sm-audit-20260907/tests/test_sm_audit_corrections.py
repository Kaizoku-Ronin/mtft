"""Public-contract regressions for SM-AUDIT-01 and SM-AUDIT-02."""
import numpy as np
import pytest

from mtft.constants import HIGGS
from mtft.hosotani import HosotaniMTFT
from mtft.lattice import (
    LatticeConfig, random_su_n, random_su_n_RETIRED_SM_AUDIT_02,
)


def test_public_quartic_reproduces_higgs_mass_and_hosotani():
    assert 2 * HIGGS.lambda_quartic * HIGGS.V_EW**2 == pytest.approx(
        HIGGS.m_H**2, rel=2e-14
    )
    assert HIGGS.lambda_quartic == pytest.approx(
        HosotaniMTFT().higgs_self_coupling(), rel=2e-14
    )
    assert HIGGS.lambda_quartic_RETIRED_SM_AUDIT_01 == pytest.approx(
        4 * HIGGS.lambda_quartic, rel=2e-14
    )


@pytest.mark.parametrize('N', [2, 3, 5])
def test_random_su_n_group_membership(N):
    for seed in range(16):
        U = random_su_n(N, np.random.default_rng(seed))
        np.testing.assert_allclose(U.conj().T @ U, np.eye(N), atol=4e-14, rtol=0)
        assert abs(np.linalg.det(U) - 1) < 4e-14


def test_hot_start_uses_corrected_sampler():
    cfg = LatticeConfig(N=3, L=2)
    cfg.hot_start(np.random.default_rng(20260907))
    links = cfg.links.reshape(-1, 3, 3)
    assert np.max(np.abs(np.linalg.det(links) - 1)) < 4e-14
    assert np.max(np.abs(links.conj().transpose(0, 2, 1) @ links - np.eye(3))) < 4e-14


def test_historical_sampler_reproduces_recorded_defect():
    U = random_su_n_RETIRED_SM_AUDIT_02(3, np.random.default_rng(0))
    assert abs(np.linalg.det(U) - 1) == pytest.approx(1.0278965, abs=1e-7)
